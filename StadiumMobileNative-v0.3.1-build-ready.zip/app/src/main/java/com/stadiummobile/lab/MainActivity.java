package com.stadiummobile.lab;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int REQ_AUDIO = 1001;
    private static final int REQ_FILE = 1002;
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private AudioEngine audioEngine;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        audioEngine = new AudioEngine(this);
        setupWebView();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
        }
    }

    private void setupWebView() {
        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("audio/*");
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                try { startActivityForResult(i, REQ_FILE); }
                catch (ActivityNotFoundException e) { fileCallback = null; return false; }
                return true;
            }
        });
        webView.addJavascriptInterface(new NativeBridge(), "NativeAudio");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE && fileCallback != null) {
            Uri[] out = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int n = data.getClipData().getItemCount();
                    out = new Uri[n];
                    for (int x=0; x<n; x++) out[x] = data.getClipData().getItemAt(x).getUri();
                } else if (data.getData() != null) out = new Uri[]{data.getData()};
            }
            fileCallback.onReceiveValue(out); fileCallback = null;
        }
    }

    @Override protected void onDestroy() {
        audioEngine.stop();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    public class NativeBridge {
        @JavascriptInterface public boolean isNative() { return true; }

        @JavascriptInterface public String getDevices() {
            try {
                JSONObject o = new JSONObject();
                o.put("inputs", audioEngine.deviceJson(true));
                o.put("outputs", audioEngine.deviceJson(false));
                return o.toString();
            } catch (Exception e) { return "{\"inputs\":[],\"outputs\":[]}"; }
        }

        @JavascriptInterface public String startUsbAudio(int inputId, int outputId) {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO));
                return "Audio permission requested. Tap Start USB Guitar again after allowing it.";
            }
            return audioEngine.start(inputId, outputId);
        }

        @JavascriptInterface public void stop() { audioEngine.stop(); }
        @JavascriptInterface public void syncState(String stateJson) { audioEngine.applyState(stateJson); }
        @JavascriptInterface public void triggerSwell() { audioEngine.triggerSwell(); }
        @JavascriptInterface public void setDelayHold(boolean on) { audioEngine.setDelayHold(on); }
        @JavascriptInterface public void tapTempo(long timeMs) { audioEngine.tapTempo(timeMs); }
        @JavascriptInterface public String getStatus() { return audioEngine.statusJson(); }

        @JavascriptInterface public void openDeplike() {
            runOnUiThread(() -> {
                Intent launch = getPackageManager().getLaunchIntentForPackage("com.deplike.andrig");
                if (launch != null) startActivity(launch);
                else {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.deplike.andrig"))); }
                    catch (Exception e) { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.deplike.andrig"))); }
                }
            });
        }

        @JavascriptInterface public void shareFile(String fileName, String mimeType, String content) {
            runOnUiThread(() -> {
                try {
                    File dir = new File(getCacheDir(), "exports"); if (!dir.exists()) dir.mkdirs();
                    File f = new File(dir, fileName.replaceAll("[^A-Za-z0-9._ -]", "_"));
                    try (FileOutputStream fos = new FileOutputStream(f)) { fos.write(content.getBytes(StandardCharsets.UTF_8)); }
                    Uri uri = ShareFileProvider.uriForFile(MainActivity.this, f);
                    Intent share = new Intent(Intent.ACTION_SEND);
                    share.setType(mimeType == null ? "application/octet-stream" : mimeType);
                    share.putExtra(Intent.EXTRA_STREAM, uri);
                    share.putExtra(Intent.EXTRA_TEXT, "Stadium Mobile Lab preset transfer");
                    share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(share, "Save or share preset"));
                } catch (Exception e) { Toast.makeText(MainActivity.this, "Share failed: "+e.getMessage(), Toast.LENGTH_LONG).show(); }
            });
        }

        @JavascriptInterface public void openAudioSettings() {
            runOnUiThread(() -> startActivity(new Intent(Settings.ACTION_SOUND_SETTINGS)));
        }
    }
}
