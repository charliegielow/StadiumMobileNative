# Stadium Mobile Lab Native v0.3

Unofficial Android-native guitar processor and Helix Stadium training lab.

The native build does **not** use Chrome microphone routing for live guitar. It enumerates Android audio devices, requires a USB input for live mode, calls `AudioRecord.setPreferredDevice()` and checks the recorder's routed input when Android reports it. If Android routes to an ambient/phone microphone instead, live audio is stopped.

## Signal path

`USB Guitar → Compressor → OD1 → OD2 → Amp → Cab → Chorus → Delay → Reverb → Android/USB Output`

## Included controls

Compressor, OD1, OD2, amp, cab, chorus, delay, reverb, Amp Boost, Delay Hold, Swell, Mute, master volume, dry/processed A-B, tap tempo, tuner, input/output meters, snapshots, persistent presets, local backing tracks, Android share-sheet export, and Deplike Companion.

## Build

The included GitHub Actions workflow builds `Stadium-Mobile-Lab-v0.3.0.apk`.

## Important

This is not a Line 6 product and does not contain Line 6/Helix modeling code. The DSP is an approximation for practice/training. Experimental `.hlx` exports should be validated in official Line 6 software before hardware use.
