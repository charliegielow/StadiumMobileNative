#include <jni.h>
#include <aaudio/AAudio.h>
#include <android/log.h>

#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <string>
#include <thread>

#define LOG_TAG "StadiumAAudio"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

namespace {
constexpr int32_t kSampleRate = 48000;
constexpr uint32_t kRingSize = 32768; // power of two
constexpr uint32_t kRingMask = kRingSize - 1;
constexpr int kPitchSize = 4096;
constexpr float kPi = 3.14159265358979323846f;

inline float clamp1(float x) { return std::max(-1.0f, std::min(1.0f, x)); }
inline float blend(float dry, float wet, float mix) { return dry * (1.0f - mix) + wet * mix; }

struct State {
    float inputGain = 1.0f, master = 0.75f, bpm = 72.0f;
    float compThreshold = .48f, compRatio = .35f, compAttack = .2f, compRelease = .4f, compMix = 1.0f;
    float od1Gain = .24f, od1Tone = .5f, od1Mix = 1.0f;
    float od2Gain = .28f, od2Tone = .55f, od2Mix = 1.0f;
    float ampDrive = .34f, ampBass = .46f, ampMid = .51f, ampTreble = .6f, ampCut = .45f;
    float cabLow = .18f, cabHigh = .72f, cabRes = .5f;
    float chorusRate = .2f, chorusDepth = .35f, chorusMix = .22f;
    float delayFeedback = .38f, delayMix = .28f, delayTone = .55f;
    float revMix = .24f, revDecay = .58f;
    uint32_t blockMask = 1u | 8u | 16u | 64u | 128u;
    uint32_t flags = 0;
};

class Engine {
public:
    Engine() {
        for (auto &v : pitchRing_) v.store(0.0f, std::memory_order_relaxed);
        states_[0] = State{};
        states_[1] = states_[0];
    }

    ~Engine() { stop(); }

    std::string start(int32_t inputDevice, int32_t outputDevice, const std::string &mode) {
        std::lock_guard<std::mutex> lock(controlMutex_);
        stopUnlocked();
        requestedInput_ = inputDevice;
        requestedOutput_ = outputDevice;
        mode_ = (mode == "stable") ? 2 : ((mode == "low") ? 1 : 0);
        lastError_.store(0, std::memory_order_release);
        inputUnderruns_.store(0, std::memory_order_relaxed);
        outputUnderruns_.store(0, std::memory_order_relaxed);
        lateDrops_.store(0, std::memory_order_relaxed);
        writeIndex_.store(0, std::memory_order_relaxed);
        readIndex_.store(0, std::memory_order_relaxed);
        pitchWrite_.store(0, std::memory_order_relaxed);
        inputMeter_.store(0, std::memory_order_relaxed);
        outputMeter_.store(0, std::memory_order_relaxed);
        pitchHz_.store(0, std::memory_order_relaxed);
        pitchCents_.store(0, std::memory_order_relaxed);
        pitchMidi_.store(-1, std::memory_order_relaxed);
        resetDsp();

        aaudio_result_t r = openOutput(mode_ == 0);
        if (r != AAUDIO_OK) {
            return errorString("Could not open AAudio output", r);
        }
        r = openInput(mode_ == 0);
        if (r != AAUDIO_OK) {
            closeStream(outputStream_);
            return errorString("Could not open AAudio USB input", r);
        }

        const int32_t outBurst = std::max(1, AAudioStream_getFramesPerBurst(outputStream_));
        const int32_t inBurst = std::max(1, AAudioStream_getFramesPerBurst(inputStream_));
        burstFrames_ = std::max(outBurst, inBurst);
        const int periods = mode_ == 0 ? 1 : (mode_ == 1 ? 2 : 4);
        ringTargetFrames_ = (mode_ == 0) ? 0 : burstFrames_ * (mode_ == 1 ? 1 : 3);

        int32_t setIn = AAudioStream_setBufferSizeInFrames(inputStream_, std::max(inBurst, inBurst * periods));
        int32_t setOut = AAudioStream_setBufferSizeInFrames(outputStream_, std::max(outBurst, outBurst * periods));
        inputBufferFrames_ = setIn > 0 ? setIn : AAudioStream_getBufferSizeInFrames(inputStream_);
        outputBufferFrames_ = setOut > 0 ? setOut : AAudioStream_getBufferSizeInFrames(outputStream_);

        running_.store(true, std::memory_order_release);
        r = AAudioStream_requestStart(inputStream_);
        if (r != AAUDIO_OK) {
            stopUnlocked();
            return errorString("Could not start AAudio input", r);
        }

        // Prefill only the minimum target needed for stable callback alignment.
        const uint64_t need = static_cast<uint64_t>(ringTargetFrames_ + burstFrames_);
        for (int i = 0; i < 50; ++i) {
            uint64_t w = writeIndex_.load(std::memory_order_acquire);
            uint64_t rd = readIndex_.load(std::memory_order_acquire);
            if (w - rd >= need) break;
            std::this_thread::sleep_for(std::chrono::milliseconds(1));
        }

        r = AAudioStream_requestStart(outputStream_);
        if (r != AAUDIO_OK) {
            stopUnlocked();
            return errorString("Could not start AAudio output", r);
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(8));
        actualInput_ = AAudioStream_getDeviceId(inputStream_);
        actualOutput_ = AAudioStream_getDeviceId(outputStream_);
        sampleRate_ = AAudioStream_getSampleRate(outputStream_);
        if (sampleRate_ <= 0) sampleRate_ = kSampleRate;

        // Fail closed rather than silently falling back to the phone microphone.
        if (actualInput_ != requestedInput_) {
            int got = actualInput_;
            stopUnlocked();
            char b[180];
            std::snprintf(b, sizeof(b), "ERROR: AAudio routed input device #%d instead of selected USB #%d.", got, requestedInput_);
            return b;
        }

        tunerRun_.store(true, std::memory_order_release);
        tunerThread_ = std::thread([this]() { tunerLoop(); });

        LOGI("Started AAudio input=%d output=%d burst=%d mode=%d", actualInput_, actualOutput_, burstFrames_, mode_);
        return statusJson();
    }

    void stop() {
        std::lock_guard<std::mutex> lock(controlMutex_);
        stopUnlocked();
    }

    void setState(const float *v, int n, uint32_t mask, uint32_t flags) {
        int current = activeState_.load(std::memory_order_acquire);
        int next = 1 - current;
        states_[next] = states_[current];
        State &s = states_[next];
        if (n >= 30) {
            s.inputGain=v[0]; s.master=v[1]; s.bpm=v[2];
            s.compThreshold=v[3]; s.compRatio=v[4]; s.compAttack=v[5]; s.compRelease=v[6]; s.compMix=v[7];
            s.od1Gain=v[8]; s.od1Tone=v[9]; s.od1Mix=v[10]; s.od2Gain=v[11]; s.od2Tone=v[12]; s.od2Mix=v[13];
            s.ampDrive=v[14]; s.ampBass=v[15]; s.ampMid=v[16]; s.ampTreble=v[17]; s.ampCut=v[18];
            s.cabLow=v[19]; s.cabHigh=v[20]; s.cabRes=v[21];
            s.chorusRate=v[22]; s.chorusDepth=v[23]; s.chorusMix=v[24];
            s.delayFeedback=v[25]; s.delayMix=v[26]; s.delayTone=v[27];
            s.revMix=v[28]; s.revDecay=v[29];
        }
        s.blockMask = mask;
        s.flags = flags;
        activeState_.store(next, std::memory_order_release);
    }

    void setDelayHold(bool on) {
        int current = activeState_.load(std::memory_order_acquire), next=1-current;
        states_[next]=states_[current];
        if(on) states_[next].flags |= 2u; else states_[next].flags &= ~2u;
        activeState_.store(next,std::memory_order_release);
    }

    void setBpm(float bpm) {
        int current = activeState_.load(std::memory_order_acquire), next=1-current;
        states_[next]=states_[current]; states_[next].bpm=std::max(40.0f,std::min(240.0f,bpm));
        activeState_.store(next,std::memory_order_release);
    }

    void triggerSwell() { swellTrigger_.store(true, std::memory_order_release); }

    std::string statusJson() const {
        const State s = states_[activeState_.load(std::memory_order_acquire)];
        int midi = pitchMidi_.load(std::memory_order_relaxed);
        const char *names[12] = {"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"};
        char note[16] = "—";
        if (midi >= 0) std::snprintf(note, sizeof(note), "%s%d", names[(midi%12+12)%12], midi/12-1);
        const float estimated = (ringTargetFrames_ + std::max(0, outputBufferFrames_)) * 1000.0f / std::max(1, sampleRate_);
        char b[1152];
        std::snprintf(b,sizeof(b),
            "{\"running\":%s,\"engine\":\"AAudio C++ callback\",\"inputId\":%d,\"outputId\":%d,"
            "\"inputMeter\":%.6f,\"outputMeter\":%.6f,\"pitch\":%.3f,\"note\":\"%s\",\"cents\":%.2f,"
            "\"bpm\":%.2f,\"delayMs\":%d,\"sampleRate\":%d,\"burstFrames\":%d,\"nativeBurstFrames\":%d,"
            "\"blockFrames\":%d,\"inputBufferFrames\":%d,\"outputBufferFrames\":%d,\"ringTargetFrames\":%d,"
            "\"estimatedBufferLatencyMs\":%.2f,\"outputUnderruns\":%u,\"lateDrops\":%u,"
            "\"sharing\":\"%s/%s\",\"error\":\"%s\",\"warning\":\"%s\"}",
            running_.load(std::memory_order_acquire)?"true":"false", actualInput_,actualOutput_,
            inputMeter_.load(std::memory_order_relaxed),outputMeter_.load(std::memory_order_relaxed),
            pitchHz_.load(std::memory_order_relaxed),note,pitchCents_.load(std::memory_order_relaxed),
            s.bpm,static_cast<int>(std::lround(45000.0f/std::max(1.0f,s.bpm))),sampleRate_,burstFrames_,burstFrames_,burstFrames_,
            inputBufferFrames_,outputBufferFrames_,ringTargetFrames_,estimated,
            outputUnderruns_.load(std::memory_order_relaxed),lateDrops_.load(std::memory_order_relaxed),
            exclusiveInput_?"EXCLUSIVE":"SHARED",exclusiveOutput_?"EXCLUSIVE":"SHARED",
            lastError_.load(std::memory_order_relaxed)==0?"":"AAudio stream error",
            mode_==0?"ULTRA LOW uses one-burst AAudio buffers. If you hear crackles, switch to LOW.":"");
        return b;
    }

private:
    static aaudio_data_callback_result_t inputCallback(AAudioStream*, void *user, void *audio, int32_t frames) {
        return static_cast<Engine*>(user)->onInput(static_cast<float*>(audio), frames);
    }
    static aaudio_data_callback_result_t outputCallback(AAudioStream *stream, void *user, void *audio, int32_t frames) {
        return static_cast<Engine*>(user)->onOutput(stream, static_cast<float*>(audio), frames);
    }
    static void errorCallback(AAudioStream*, void *user, aaudio_result_t error) {
        Engine *e=static_cast<Engine*>(user); e->lastError_.store(static_cast<int>(error),std::memory_order_release); e->running_.store(false,std::memory_order_release);
    }

    aaudio_data_callback_result_t onInput(const float *in, int32_t frames) {
        if (!in || frames <= 0) return AAUDIO_CALLBACK_RESULT_CONTINUE;
        State s=states_[activeState_.load(std::memory_order_acquire)];
        uint64_t w=writeIndex_.load(std::memory_order_relaxed);
        uint64_t r=readIndex_.load(std::memory_order_acquire);
        uint64_t used=w-r;
        uint64_t freeFrames=used<kRingSize?kRingSize-used:0;
        int32_t writeFrames=static_cast<int32_t>(std::min<uint64_t>(frames,freeFrames));
        double sum=0.0;
        uint64_t pw=pitchWrite_.load(std::memory_order_relaxed);
        for(int32_t i=0;i<frames;i++){
            float x=clamp1(in[i]*s.inputGain);
            sum += x*x;
            pitchRing_[pw & (kPitchSize-1)].store(x,std::memory_order_relaxed); ++pw;
            if(i<writeFrames) ring_[static_cast<uint32_t>(w+i)&kRingMask]=x;
        }
        pitchWrite_.store(pw,std::memory_order_release);
        if(writeFrames>0) writeIndex_.store(w+writeFrames,std::memory_order_release);
        if(writeFrames<frames) inputUnderruns_.fetch_add(1,std::memory_order_relaxed);
        inputMeter_.store(static_cast<float>(std::sqrt(sum/std::max(1,frames))),std::memory_order_relaxed);
        return AAUDIO_CALLBACK_RESULT_CONTINUE;
    }

    aaudio_data_callback_result_t onOutput(AAudioStream *stream, float *out, int32_t frames) {
        if (!out || frames <= 0) return AAUDIO_CALLBACK_RESULT_CONTINUE;
        State s=states_[activeState_.load(std::memory_order_acquire)];
        uint64_t r=readIndex_.load(std::memory_order_relaxed);
        uint64_t w=writeIndex_.load(std::memory_order_acquire);
        uint64_t available=w-r;
        const uint64_t desired=static_cast<uint64_t>(std::max(0,ringTargetFrames_));
        if(available > static_cast<uint64_t>(frames)+desired){
            uint64_t skip=available-(static_cast<uint64_t>(frames)+desired);
            r += skip; available -= skip; lateDrops_.fetch_add(static_cast<uint32_t>(skip),std::memory_order_relaxed);
        }
        const int32_t n=static_cast<int32_t>(std::min<uint64_t>(available,frames));
        double sum=0.0;
        if(swellTrigger_.exchange(false,std::memory_order_acq_rel)){swellGain_=0.001f;swellTarget_=1.0f;}
        for(int32_t i=0;i<frames;i++){
            float raw = i<n ? ring_[static_cast<uint32_t>(r+i)&kRingMask] : 0.0f;
            float y=process(raw,s);
            if(s.flags&4u) y=0.0f;
            y=clamp1(y*s.master);
            out[i*2]=y; out[i*2+1]=y; sum+=y*y;
        }
        readIndex_.store(r+n,std::memory_order_release);
        if(n<frames) outputUnderruns_.fetch_add(1,std::memory_order_relaxed);
        if((callbackCount_++ & 127u)==0u){
            int32_t xr=AAudioStream_getXRunCount(stream);
            if(xr>=0) outputUnderruns_.store(static_cast<uint32_t>(xr),std::memory_order_relaxed);
        }
        outputMeter_.store(static_cast<float>(std::sqrt(sum/std::max(1,frames))),std::memory_order_relaxed);
        return AAUDIO_CALLBACK_RESULT_CONTINUE;
    }

    float process(float x,const State &s){
        if(s.flags&8u) return x;
        float y=x;
        if(s.blockMask&1u) y=compress(y,s);
        if(s.blockMask&2u) y=blend(y,drive(y,s.od1Gain,s.od1Tone,od1Lp_),s.od1Mix);
        if(s.blockMask&4u) y=blend(y,drive(y,s.od2Gain,s.od2Tone,od2Lp_),s.od2Mix);
        if(s.blockMask&8u) y=amp(y,s);
        if(s.blockMask&16u) y=cab(y,s);
        if(s.blockMask&32u) y=blend(y,chorus(y,s),s.chorusMix);
        if(s.blockMask&64u) y=delay(y,s);
        if(s.blockMask&128u) y=reverb(y,s);
        if(swellGain_!=swellTarget_){swellGain_+=(swellTarget_-swellGain_)*.0025f;if(std::fabs(swellTarget_-swellGain_)<.001f)swellGain_=swellTarget_;}
        return y*swellGain_;
    }

    float compress(float x,const State&s){
        float a=std::fabs(x),atk=.002f+.04f*s.compAttack,rel=.03f+.35f*s.compRelease;
        float ca=std::exp(-1.0f/(kSampleRate*atk)),cr=std::exp(-1.0f/(kSampleRate*rel));
        compEnv_=a>compEnv_?ca*compEnv_+(1-ca)*a:cr*compEnv_+(1-cr)*a;
        float th=.03f+.32f*(1-s.compThreshold),ratio=1.5f+7*s.compRatio,g=1;
        if(compEnv_>th)g=std::pow(th/compEnv_,1-1/ratio);
        return blend(x,x*g*1.35f,s.compMix);
    }
    float drive(float x,float gain,float tone,float &lp){float g=1+gain*18,d=std::tanh(x*g);lp+=(.03f+tone*.15f)*(d-lp);return d*(.72f+tone*.18f)+lp*(.28f-tone*.18f);}
    float amp(float x,const State&s){float g=(1+s.ampDrive*9)*((s.flags&1u)?1.7f:1.0f),z=std::tanh(x*g);ampLp_+=.02f*(z-ampLp_);float high=z-ampLp_,mid=z-(high*.45f+ampLp_*.55f);float v=ampLp_*(.55f+s.ampBass)+mid*(.55f+s.ampMid)+high*(.35f+s.ampTreble*.75f);return std::tanh(v*1.15f);}
    float cab(float x,const State&s){float hpA=.992f-s.cabLow*.01f;float hp=hpA*(cabHpPrevOut_+x-cabHpPrevIn_);cabHpPrevIn_=x;cabHpPrevOut_=hp;float fc=3800+s.cabHigh*7000;float a=1-std::exp(-2*kPi*fc/kSampleRate);cabLp_+=a*(hp-cabLp_);float reson=(cabLp_-cabResPrev_)*(s.cabRes-.5f)*.35f;cabResPrev_=cabLp_;return cabLp_+reson;}
    float chorus(float x,const State&s){chorusBuf_[chorusPos_]=x;chorusPhase_+=2*kPi*(.15f+s.chorusRate*2.2f)/kSampleRate;if(chorusPhase_>2*kPi)chorusPhase_-=2*kPi;int d=static_cast<int>(480+s.chorusDepth*500*(.5f+.5f*std::sin(chorusPhase_)));int r=chorusPos_-d;if(r<0)r+=static_cast<int>(chorusBuf_.size());float y=chorusBuf_[r];chorusPos_=(chorusPos_+1)%chorusBuf_.size();return y;}
    float delay(float x,const State&s){float bpm=std::max(40.0f,std::min(240.0f,s.bpm));int ds=std::max(1,std::min(static_cast<int>(delayBuf_.size())-1,static_cast<int>(kSampleRate*(45.0f/bpm))));int r=delayPos_-ds;if(r<0)r+=delayBuf_.size();float wet=delayBuf_[r];float fb=(s.flags&2u)?.965f:(.08f+s.delayFeedback*.74f);delayBuf_[delayPos_]=clamp1(x+wet*fb);delayPos_=(delayPos_+1)%delayBuf_.size();return x+wet*s.delayMix;}
    float reverb(float x,const State&s){float sum=0,fb=.58f+s.revDecay*.32f;for(int i=0;i<4;i++){float *b=revBuf_[i].data();int len=revLen_[i],p=revPos_[i];float y=b[p];b[p]=clamp1(x*.22f+y*fb);revPos_[i]=(p+1)%len;sum+=y;}return x+sum*.25f*s.revMix;}

    void tunerLoop(){
        std::array<float,2048> b{};
        while(tunerRun_.load(std::memory_order_acquire)){
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
            uint64_t w=pitchWrite_.load(std::memory_order_acquire);
            if(w<2048)continue;
            for(int i=0;i<2048;i++)b[i]=pitchRing_[(w-2048+i)&(kPitchSize-1)].load(std::memory_order_relaxed);
            double rms=0;for(float v:b)rms+=v*v;rms=std::sqrt(rms/b.size());
            if(rms<.008){pitchHz_.store(0);pitchMidi_.store(-1);pitchCents_.store(0);continue;}
            int minLag=kSampleRate/1000,maxLag=std::min(kSampleRate/55,1000),best=0;double bestVal=0;
            for(int lag=minLag;lag<=maxLag;lag+=2){double sum=0;for(int i=0;i<static_cast<int>(b.size())-lag;i+=2)sum+=b[i]*b[i+lag];if(sum>bestVal){bestVal=sum;best=lag;}}
            if(best<=0)continue;
            float f=kSampleRate/static_cast<float>(best);double nn=12*std::log(f/440.0)/std::log(2.0)+69;int n=static_cast<int>(std::lround(nn));
            pitchHz_.store(f,std::memory_order_relaxed);pitchMidi_.store(n,std::memory_order_relaxed);pitchCents_.store(static_cast<float>((nn-n)*100),std::memory_order_relaxed);
        }
    }

    aaudio_result_t openOutput(bool tryExclusive){
        aaudio_result_t r=openOutputOnce(tryExclusive?AAUDIO_SHARING_MODE_EXCLUSIVE:AAUDIO_SHARING_MODE_SHARED);
        if(r!=AAUDIO_OK && tryExclusive){ closeStream(outputStream_); r=openOutputOnce(AAUDIO_SHARING_MODE_SHARED); }
        return r;
    }
    aaudio_result_t openOutputOnce(aaudio_sharing_mode_t sharing){
        AAudioStreamBuilder *b=nullptr; aaudio_result_t r=AAudio_createStreamBuilder(&b); if(r!=AAUDIO_OK)return r;
        AAudioStreamBuilder_setDirection(b,AAUDIO_DIRECTION_OUTPUT);AAudioStreamBuilder_setPerformanceMode(b,AAUDIO_PERFORMANCE_MODE_LOW_LATENCY);AAudioStreamBuilder_setSharingMode(b,sharing);AAudioStreamBuilder_setFormat(b,AAUDIO_FORMAT_PCM_FLOAT);AAudioStreamBuilder_setSampleRate(b,kSampleRate);AAudioStreamBuilder_setChannelCount(b,2);if(requestedOutput_>=0)AAudioStreamBuilder_setDeviceId(b,requestedOutput_);AAudioStreamBuilder_setDataCallback(b,outputCallback,this);AAudioStreamBuilder_setErrorCallback(b,errorCallback,this);
        r=AAudioStreamBuilder_openStream(b,&outputStream_);AAudioStreamBuilder_delete(b);if(r==AAUDIO_OK)exclusiveOutput_=AAudioStream_getSharingMode(outputStream_)==AAUDIO_SHARING_MODE_EXCLUSIVE;return r;
    }
    aaudio_result_t openInput(bool tryExclusive){
        aaudio_result_t r=openInputOnce(tryExclusive?AAUDIO_SHARING_MODE_EXCLUSIVE:AAUDIO_SHARING_MODE_SHARED);
        if(r!=AAUDIO_OK && tryExclusive){ closeStream(inputStream_); r=openInputOnce(AAUDIO_SHARING_MODE_SHARED); }
        return r;
    }
    aaudio_result_t openInputOnce(aaudio_sharing_mode_t sharing){
        AAudioStreamBuilder *b=nullptr; aaudio_result_t r=AAudio_createStreamBuilder(&b); if(r!=AAUDIO_OK)return r;
        AAudioStreamBuilder_setDirection(b,AAUDIO_DIRECTION_INPUT);AAudioStreamBuilder_setPerformanceMode(b,AAUDIO_PERFORMANCE_MODE_LOW_LATENCY);AAudioStreamBuilder_setSharingMode(b,sharing);AAudioStreamBuilder_setFormat(b,AAUDIO_FORMAT_PCM_FLOAT);AAudioStreamBuilder_setSampleRate(b,kSampleRate);AAudioStreamBuilder_setChannelCount(b,1);AAudioStreamBuilder_setDeviceId(b,requestedInput_);AAudioStreamBuilder_setDataCallback(b,inputCallback,this);AAudioStreamBuilder_setErrorCallback(b,errorCallback,this);
        r=AAudioStreamBuilder_openStream(b,&inputStream_);AAudioStreamBuilder_delete(b);if(r==AAUDIO_OK)exclusiveInput_=AAudioStream_getSharingMode(inputStream_)==AAUDIO_SHARING_MODE_EXCLUSIVE;return r;
    }

    static void closeStream(AAudioStream *&s){if(s){AAudioStream_requestStop(s);AAudioStream_close(s);s=nullptr;}}
    void stopUnlocked(){
        startedOnce_=true; running_.store(false,std::memory_order_release); tunerRun_.store(false,std::memory_order_release);
        closeStream(outputStream_); closeStream(inputStream_);
        if(tunerThread_.joinable())tunerThread_.join();
        actualInput_=-1;actualOutput_=-1;inputBufferFrames_=outputBufferFrames_=ringTargetFrames_=0;
    }
    static std::string errorString(const char *prefix,aaudio_result_t r){char b[256];std::snprintf(b,sizeof(b),"ERROR: %s: %s (%d)",prefix,AAudio_convertResultToText(r),r);return b;}
    void resetDsp(){compEnv_=od1Lp_=od2Lp_=ampLp_=cabHpPrevIn_=cabHpPrevOut_=cabLp_=cabResPrev_=0;chorusPos_=0;chorusPhase_=0;delayPos_=0;swellGain_=1;swellTarget_=1;std::fill(chorusBuf_.begin(),chorusBuf_.end(),0);std::fill(delayBuf_.begin(),delayBuf_.end(),0);for(auto &a:revBuf_)std::fill(a.begin(),a.end(),0);revPos_.fill(0);}

    mutable std::mutex controlMutex_;
    AAudioStream *inputStream_=nullptr,*outputStream_=nullptr;
    std::atomic<bool> running_{false},tunerRun_{false},swellTrigger_{false};
    bool startedOnce_=false;
    std::thread tunerThread_;
    int requestedInput_=-1,requestedOutput_=-1,actualInput_=-1,actualOutput_=-1,mode_=0;
    int sampleRate_=kSampleRate,burstFrames_=0,inputBufferFrames_=0,outputBufferFrames_=0,ringTargetFrames_=0;
    bool exclusiveInput_=false,exclusiveOutput_=false;
    std::atomic<int> lastError_{0};
    std::array<State,2> states_{}; std::atomic<int> activeState_{0};
    std::array<float,kRingSize> ring_{}; std::atomic<uint64_t> writeIndex_{0},readIndex_{0};
    std::array<std::atomic<float>,kPitchSize> pitchRing_; std::atomic<uint64_t> pitchWrite_{0};
    std::atomic<float> inputMeter_{0},outputMeter_{0},pitchHz_{0},pitchCents_{0};std::atomic<int> pitchMidi_{-1};
    std::atomic<uint32_t> inputUnderruns_{0},outputUnderruns_{0},lateDrops_{0}; uint32_t callbackCount_=0;
    float compEnv_=0,od1Lp_=0,od2Lp_=0,ampLp_=0,cabHpPrevIn_=0,cabHpPrevOut_=0,cabLp_=0,cabResPrev_=0;
    std::array<float,4096> chorusBuf_{};int chorusPos_=0;float chorusPhase_=0;
    std::array<float,kSampleRate*2> delayBuf_{};int delayPos_=0;
    std::array<std::array<float,9479>,4> revBuf_{};const std::array<int,4> revLen_{{6137,7297,8059,9479}};std::array<int,4> revPos_{{0,0,0,0}};
    float swellGain_=1,swellTarget_=1;
};

Engine gEngine;

jstring toJString(JNIEnv *env,const std::string &s){return env->NewStringUTF(s.c_str());}
}

extern "C" JNIEXPORT jstring JNICALL Java_com_stadiummobile_lab_NativeAudioEngine_start(JNIEnv *env,jclass,jint inId,jint outId,jstring mode){
    const char *m=mode?env->GetStringUTFChars(mode,nullptr):nullptr;std::string ms=m?m:"ultra";if(m)env->ReleaseStringUTFChars(mode,m);return toJString(env,gEngine.start(inId,outId,ms));
}
extern "C" JNIEXPORT void JNICALL Java_com_stadiummobile_lab_NativeAudioEngine_stop(JNIEnv*,jclass){gEngine.stop();}
extern "C" JNIEXPORT void JNICALL Java_com_stadiummobile_lab_NativeAudioEngine_setState(JNIEnv *env,jclass,jfloatArray arr,jint mask,jint flags){if(!arr)return;jsize n=env->GetArrayLength(arr);jfloat *v=env->GetFloatArrayElements(arr,nullptr);if(v){gEngine.setState(v,n,static_cast<uint32_t>(mask),static_cast<uint32_t>(flags));env->ReleaseFloatArrayElements(arr,v,JNI_ABORT);}}
extern "C" JNIEXPORT void JNICALL Java_com_stadiummobile_lab_NativeAudioEngine_setDelayHold(JNIEnv*,jclass,jboolean on){gEngine.setDelayHold(on==JNI_TRUE);}
extern "C" JNIEXPORT void JNICALL Java_com_stadiummobile_lab_NativeAudioEngine_triggerSwell(JNIEnv*,jclass){gEngine.triggerSwell();}
extern "C" JNIEXPORT void JNICALL Java_com_stadiummobile_lab_NativeAudioEngine_setBpm(JNIEnv*,jclass,jfloat bpm){gEngine.setBpm(bpm);}
extern "C" JNIEXPORT jstring JNICALL Java_com_stadiummobile_lab_NativeAudioEngine_getStatus(JNIEnv *env,jclass){return toJString(env,gEngine.statusJson());}
