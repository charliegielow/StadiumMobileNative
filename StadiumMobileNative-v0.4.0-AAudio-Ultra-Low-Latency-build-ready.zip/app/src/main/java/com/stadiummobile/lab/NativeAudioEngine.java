package com.stadiummobile.lab;

final class NativeAudioEngine {
    static {
        System.loadLibrary("stadium_audio");
    }

    private NativeAudioEngine() {}

    static native String start(int inputDeviceId, int outputDeviceId, String mode);
    static native void stop();
    static native void setState(float[] values, int blockMask, int flags);
    static native void setDelayHold(boolean on);
    static native void triggerSwell();
    static native void setBpm(float bpm);
    static native String getStatus();
}
