package com.stadiummobile.lab;

import android.content.Context;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;

import org.json.JSONArray;
import org.json.JSONObject;

public class AudioEngine {
    private final AudioManager manager;
    private String activeInput="", activeOutput="", lastError="", routeWarning="";
    private volatile boolean running=false, routeConfirmed=false;
    private volatile int activeInputId=-1, activeOutputId=-1;
    private volatile String latencyMode="ultra";

    private volatile boolean comp=true, od1=false, od2=false, amp=true, cab=true, chorus=false, delay=true, reverb=true;
    private volatile boolean ampBoost=false, delayHold=false, mute=false, dry=false;
    private volatile float inputGain=1f, master=.75f, bpm=72f;
    private volatile float compThreshold=.48f, compRatio=.35f, compAttack=.2f, compRelease=.4f, compMix=1f;
    private volatile float od1Gain=.24f, od1Tone=.5f, od1Mix=1f, od2Gain=.28f, od2Tone=.55f, od2Mix=1f;
    private volatile float ampDrive=.34f, ampBass=.46f, ampMid=.51f, ampTreble=.6f, ampCut=.45f;
    private volatile float cabLow=.18f, cabHigh=.72f, cabRes=.5f;
    private volatile float chorusRate=.2f, chorusDepth=.35f, chorusMix=.22f;
    private volatile float delayFeedback=.38f, delayMix=.28f, delayTone=.55f;
    private volatile float revMix=.24f, revDecay=.58f;
    private final long[] taps=new long[4]; private int tapN=0;

    public AudioEngine(Context ctx){ manager=(AudioManager)ctx.getSystemService(Context.AUDIO_SERVICE); }

    public JSONArray deviceJson(boolean inputs){
        JSONArray a=new JSONArray();
        for(AudioDeviceInfo d: manager.getDevices(inputs?AudioManager.GET_DEVICES_INPUTS:AudioManager.GET_DEVICES_OUTPUTS)){
            try{
                JSONObject o=new JSONObject();
                o.put("id",d.getId()); o.put("name",d.getProductName().toString());
                o.put("type",d.getType()); o.put("usb",isUsb(d)); a.put(o);
            }catch(Exception ignored){}
        }
        return a;
    }

    private boolean isUsb(AudioDeviceInfo d){
        int t=d.getType();
        return t==AudioDeviceInfo.TYPE_USB_DEVICE||t==AudioDeviceInfo.TYPE_USB_HEADSET||t==AudioDeviceInfo.TYPE_USB_ACCESSORY;
    }

    private AudioDeviceInfo find(int id, boolean source){
        AudioDeviceInfo[] ds=manager.getDevices(source?AudioManager.GET_DEVICES_INPUTS:AudioManager.GET_DEVICES_OUTPUTS);
        AudioDeviceInfo usb=null;
        for(AudioDeviceInfo d:ds){ if(d.getId()==id)return d; if(usb==null&&isUsb(d))usb=d; }
        return usb;
    }

    public synchronized String start(int inputId,int outputId){ return start(inputId,outputId,"ultra"); }

    public synchronized String start(int inputId,int outputId,String requestedMode){
        stop(); lastError=""; routeWarning="";
        if("stable".equalsIgnoreCase(requestedMode)) latencyMode="stable";
        else if("low".equalsIgnoreCase(requestedMode)) latencyMode="low";
        else latencyMode="ultra";
        try{
            AudioDeviceInfo in=find(inputId,true), out=find(outputId,false);
            if(in==null) return fail("No USB input is exposed to Android native audio.");
            if(!isUsb(in)) return fail("Selected input is not a USB audio interface. Refusing the phone/ambient microphone.");
            if(out!=null && !isUsb(out)) routeWarning="Selected output is not USB; Android may use system output. ";

            activeInputId=in.getId(); activeOutputId=out==null?-1:out.getId();
            activeInput=in.getProductName()+" (#"+in.getId()+")";
            activeOutput=out==null?"Android default output":out.getProductName()+" (#"+out.getId()+")";

            pushState();
            String result=NativeAudioEngine.start(activeInputId,activeOutputId,latencyMode);
            if(result==null || result.startsWith("ERROR")){ lastError=result==null?"Native AAudio engine returned no status.":result; stop(); return lastError; }

            JSONObject ns=new JSONObject(result);
            int routedIn=ns.optInt("inputId",-1), routedOut=ns.optInt("outputId",-1);
            routeConfirmed=routedIn==activeInputId;
            if(!routeConfirmed){
                String msg="ERROR: AAudio routed input device #"+routedIn+" instead of selected USB #"+activeInputId+". Audio stopped to prevent ambient microphone capture.";
                NativeAudioEngine.stop(); running=false; return fail(msg.substring(7));
            }
            if(routedOut>=0) activeOutputId=routedOut;
            running=true;
            return "AAudio C++ USB audio started • "+latencyMode.toUpperCase()+" • "+ns.optInt("sampleRate",48000)+" Hz • "+ns.optInt("burstFrames",0)+"f burst • "+activeInput+" → "+activeOutput+(routeWarning.isEmpty()?"":" • "+routeWarning.trim());
        }catch(Throwable e){ stop(); return fail(e.getClass().getSimpleName()+": "+e.getMessage()); }
    }

    private String fail(String s){ lastError=s; return "ERROR: "+s; }

    public synchronized void stop(){
        try{ NativeAudioEngine.stop(); }catch(Throwable ignored){}
        running=false; routeConfirmed=false; activeInputId=-1; activeOutputId=-1;
    }

    public void triggerSwell(){ try{NativeAudioEngine.triggerSwell();}catch(Throwable ignored){} }

    public void setDelayHold(boolean on){ delayHold=on; try{NativeAudioEngine.setDelayHold(on);}catch(Throwable ignored){} }

    public void tapTempo(long ms){
        if(tapN>0 && ms-taps[(tapN-1)%4]>2500) tapN=0;
        taps[tapN%4]=ms; tapN++;
        if(tapN>=2){
            int count=Math.min(tapN,4), start=Math.max(0,tapN-count); double total=0; int n=0;
            for(int i=start+1;i<tapN;i++){ long a=taps[(i-1)%4], b=taps[i%4]; if(b>a){total+=b-a;n++;} }
            if(n>0){ bpm=(float)Math.max(40,Math.min(240,60000/(total/n))); try{NativeAudioEngine.setBpm(bpm);}catch(Throwable ignored){} }
        }
    }

    public void applyState(String json){
        try{
            JSONObject s=new JSONObject(json);
            inputGain=(float)s.optDouble("inputGain",inputGain); master=(float)s.optDouble("master",master); bpm=(float)s.optDouble("bpm",bpm);
            ampBoost=s.optBoolean("ampBoost",ampBoost); delayHold=s.optBoolean("delayHold",delayHold); mute=s.optBoolean("muted",mute); dry=s.optBoolean("dry",dry);
            JSONArray bs=s.optJSONArray("blocks");
            if(bs!=null) for(int i=0;i<bs.length();i++){
                JSONObject b=bs.getJSONObject(i); String id=b.optString("id"); boolean on=b.optBoolean("on",true); JSONObject p=b.optJSONObject("p");
                if("comp".equals(id)){comp=on;compThreshold=f(p,"Threshold",compThreshold);compRatio=f(p,"Ratio",compRatio);compAttack=f(p,"Attack",compAttack);compRelease=f(p,"Release",compRelease);compMix=f(p,"Mix",compMix);}
                else if("od1".equals(id)){od1=on;od1Gain=f(p,"Gain",od1Gain);od1Tone=f(p,"Tone",od1Tone);od1Mix=f(p,"Mix",od1Mix);}
                else if("od2".equals(id)){od2=on;od2Gain=f(p,"Gain",od2Gain);od2Tone=f(p,"Tone",od2Tone);od2Mix=f(p,"Mix",od2Mix);}
                else if("amp".equals(id)){amp=on;ampDrive=f(p,"Drive",ampDrive);ampBass=f(p,"Bass",ampBass);ampMid=f(p,"Mid",ampMid);ampTreble=f(p,"Treble",ampTreble);ampCut=f(p,"Cut",ampCut);}
                else if("cab".equals(id)){cab=on;cabLow=f(p,"Low Cut",cabLow);cabHigh=f(p,"High Cut",cabHigh);cabRes=f(p,"Resonance",cabRes);}
                else if("mod".equals(id)){chorus=on;chorusRate=f(p,"Rate",chorusRate);chorusDepth=f(p,"Depth",chorusDepth);chorusMix=f(p,"Mix",chorusMix);}
                else if("delay".equals(id)){delay=on;delayFeedback=f(p,"Feedback",delayFeedback);delayMix=f(p,"Mix",delayMix);delayTone=f(p,"Tone",delayTone);}
                else if("reverb".equals(id)){reverb=on;revMix=f(p,"Mix",revMix);revDecay=f(p,"Decay",revDecay);}
            }
            pushState();
        }catch(Exception e){ lastError="State sync: "+e.getMessage(); }
    }

    private float f(JSONObject p,String k,float d){ return p==null?d:(float)p.optDouble(k,d); }

    private void pushState(){
        float[] v=new float[]{
                inputGain,master,bpm,
                compThreshold,compRatio,compAttack,compRelease,compMix,
                od1Gain,od1Tone,od1Mix,od2Gain,od2Tone,od2Mix,
                ampDrive,ampBass,ampMid,ampTreble,ampCut,
                cabLow,cabHigh,cabRes,
                chorusRate,chorusDepth,chorusMix,
                delayFeedback,delayMix,delayTone,
                revMix,revDecay
        };
        int mask=(comp?1:0)|(od1?2:0)|(od2?4:0)|(amp?8:0)|(cab?16:0)|(chorus?32:0)|(delay?64:0)|(reverb?128:0);
        int flags=(ampBoost?1:0)|(delayHold?2:0)|(mute?4:0)|(dry?8:0);
        try{ NativeAudioEngine.setState(v,mask,flags); }catch(Throwable ignored){}
    }

    public String statusJson(){
        try{
            JSONObject o;
            try{o=new JSONObject(NativeAudioEngine.getStatus());}catch(Throwable t){o=new JSONObject();}
            o.put("running",running && o.optBoolean("running",false));
            o.put("input",activeInput); o.put("output",activeOutput); o.put("routeConfirmed",routeConfirmed);
            o.put("inputId",activeInputId); o.put("outputId",activeOutputId); o.put("bpm",bpm); o.put("delayMs",Math.round(45000/bpm));
            o.put("error",lastError.isEmpty()?o.optString("error",""):lastError); o.put("warning",routeWarning+o.optString("warning",""));
            o.put("latencyMode",latencyMode); o.put("captureSource","AAudio native callback");
            return o.toString();
        }catch(Exception e){ return "{}"; }
    }
}
