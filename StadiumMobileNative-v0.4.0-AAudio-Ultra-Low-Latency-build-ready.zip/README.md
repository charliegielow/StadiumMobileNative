# Stadium Mobile Lab Native v0.4.0 — AAudio Ultra Low Latency

This build moves the live guitar signal path out of Java `AudioRecord` / `AudioTrack` and into a native C++ AAudio callback engine.

## Why this version exists
v0.3.x worked, but the Java read/process/write loop still produced enough round-trip delay to make picking rhythm feel disconnected. v0.4 targets Android's native low-latency audio path instead.

## Audio modes
- **ULTRA LOW** — one-burst AAudio stream buffers, zero intentional ring-buffer reserve, EXCLUSIVE sharing requested first. This is the minimum-delay mode.
- **LOW** — two-burst stream buffers plus one burst of ring reserve for additional stability.
- **STABLE** — four-burst stream buffers plus three bursts of ring reserve.

If ULTRA LOW crackles or reports xruns, use LOW. Use STABLE only if LOW is unstable.

## Native path
`USB Guitar -> AAudio input callback -> C++ DSP -> AAudio output callback -> USB interface output`

The native engine retains the existing practice DSP blocks: compressor, OD1, OD2, amp, cab, chorus, delay, reverb, amp boost, delay hold, swell, mute, master, dry/processed A-B, tuner, and tap tempo.

## USB microphone protection
The Java layer still requires a USB `AudioDeviceInfo` for the input. The AAudio stream is opened against that exact Android device ID. After the native stream starts, the app checks AAudio's routed input device ID; if it does not match the selected USB interface, audio is stopped rather than silently using the phone microphone.

## Monitoring
Use wired headphones/speakers connected to the audio interface. Disable any interface **Direct Monitor** function when judging processed-app latency; direct dry monitoring mixed with delayed processed audio can make timing sound worse.

## Build
The v5 GitHub Actions workflow installs Android API 35, NDK 27.2, CMake 3.22.1 and builds an arm64-v8a debug APK.

This is an unofficial practice/training app and is not a Line 6 product.
