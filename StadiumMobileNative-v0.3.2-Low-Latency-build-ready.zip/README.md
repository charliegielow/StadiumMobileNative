# Stadium Mobile Lab Native v0.3.2 — Low Latency

This build reduces live guitar monitoring delay while preserving native USB-input protection and the Stadium-style training UI.

## Low-latency changes
- LOW LATENCY mode is now the default.
- Smaller DSP processing blocks (typically ~96–120 frames depending on the Android native burst size).
- AudioRecord requests PERFORMANCE_MODE_LOW_LATENCY.
- Android VOICE_PERFORMANCE capture is tried first on supported Android versions, then UNPROCESSED, then DEFAULT as a guarded fallback.
- AudioTrack remains PERFORMANCE_MODE_LOW_LATENCY and requests a smaller runtime buffer.
- STABLE mode is available if LOW LATENCY produces crackles or dropouts.
- On-screen diagnostics show capture source, native burst, DSP block size, input/output buffer frames, estimated buffer latency, and underrun count.
- USB-route verification remains enabled to prevent accidental ambient-microphone capture.

## Monitoring
For minimum latency, connect wired headphones or speakers to the USB audio interface. Bluetooth monitoring adds substantial delay and should not be used for live guitar monitoring.

## Signal path
`USB Guitar Input -> Comp -> OD1 -> OD2 -> Amp -> Cab -> Chorus -> Delay -> Reverb -> USB/Android Output`

## Important
The displayed latency is an estimate based on Android buffer sizes, not a measured round-trip hardware latency. USB/interface/driver conversion adds additional delay. The DSP is an unofficial practice implementation and is not Line 6 modeling code.
