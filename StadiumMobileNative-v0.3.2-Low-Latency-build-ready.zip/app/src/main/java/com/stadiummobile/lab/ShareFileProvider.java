package com.stadiummobile.lab;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileNotFoundException;

public class ShareFileProvider extends ContentProvider {
    private static File root;
    public static Uri uriForFile(Context context, File file) {
        root = context.getCacheDir();
        String rel = file.getAbsolutePath().substring(root.getAbsolutePath().length());
        return new Uri.Builder().scheme("content").authority(context.getPackageName()+".files").path(rel).build();
    }
    @Override public boolean onCreate(){ root=getContext().getCacheDir(); return true; }
    private File file(Uri uri){
        String path = uri.getPath() == null ? "" : uri.getPath();
        while (path.startsWith("/")) path = path.substring(1);
        File f=new File(root, path);
        try {
            String rootPath = root.getCanonicalPath();
            String filePath = f.getCanonicalPath();
            if(!(filePath.equals(rootPath) || filePath.startsWith(rootPath + File.separator))) throw new SecurityException();
        } catch(Exception e){ throw new SecurityException(e); }
        return f;
    }
    @Override public String getType(Uri uri){ return "application/octet-stream"; }
    @Override public ParcelFileDescriptor openFile(Uri uri,String mode) throws FileNotFoundException { return ParcelFileDescriptor.open(file(uri), ParcelFileDescriptor.MODE_READ_ONLY); }
    @Override public Cursor query(Uri uri,String[] projection,String selection,String[] selectionArgs,String sortOrder){ File f=file(uri); MatrixCursor c=new MatrixCursor(new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE}); c.addRow(new Object[]{f.getName(),f.length()}); return c; }
    @Override public int delete(Uri u,String s,String[] a){return 0;} @Override public int update(Uri u,ContentValues v,String s,String[] a){return 0;} @Override public Uri insert(Uri u,ContentValues v){return null;}
}
