package com.stadiummobile.lab;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioDeviceInfo;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Process;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.concurrent.atomic.AtomicBoolean;

public class AudioEngine {
    private static final int SR = 48000;
    private static final int DEFAULT_BURST = 192;
    private final AudioManager manager;
    private final AtomicBoolean running = new AtomicBoolean(false);
    private AudioRecord record;
    private AudioTrack track;
    private Thread thread;
    private String activeInput="", activeOutput="", lastError="", routeWarning="";
    private volatile boolean routeConfirmed=false;
    private volatile int activeInputId=-1, activeOutputId=-1;
    private volatile float inputMeter=0, outputMeter=0, pitchHz=0, cents=0;
    private volatile String note="—";
    private volatile boolean comp=true, od1=false, od2=false, amp=true, cab=true, chorus=false, delay=true, reverb=true, ampBoost=false, delayHold=false, mute=false, dry=false;
    private volatile float inputGain=1f, master=.75f, bpm=72f;
    private volatile float compThreshold=.48f, compRatio=.35f, compAttack=.2f, compRelease=.4f, compMix=1f;
    private volatile float od1Gain=.24f, od1Tone=.5f, od1Mix=1f, od2Gain=.28f, od2Tone=.55f, od2Mix=1f;
    private volatile float ampDrive=.34f, ampBass=.46f, ampMid=.51f, ampTreble=.6f, ampCut=.45f, cabLow=.18f, cabHigh=.72f, cabRes=.5f;
    private volatile float chorusRate=.2f, chorusDepth=.35f, chorusMix=.22f;
    private volatile float delayFeedback=.38f, delayMix=.28f, delayTone=.55f;
    private volatile float revMix=.24f, revDecay=.58f;
    private volatile float swellGain=1f, swellTarget=1f;
    private long[] taps=new long[4]; int tapN=0;

    // Low-latency diagnostics / tuning.
    private volatile String latencyMode="low";
    private volatile int nativeBurstFrames=DEFAULT_BURST;
    private volatile int blockFrames=96;
    private volatile int inputBufferFrames=0;
    private volatile int outputBufferFrames=0;
    private volatile int outputUnderruns=0;
    private volatile float estimatedBufferLatencyMs=0f;
    private volatile String captureSource="";

    // stateful DSP
    private float compEnv=0;
    private float lp=0, hpPrevIn=0, hpPrevOut=0, cabLp=0;
    private final float[] chorusBuf=new float[4096]; int chorusPos=0; float chorusPhase=0;
    private final float[] delayBuf=new float[SR*2]; int delayPos=0;
    private final float[][] revBuf={new float[6137],new float[7297],new float[8059],new float[9479]};
    private final int[] revPos={0,0,0,0};
    private final float[] pitchBuf=new float[4096]; int pitchPos=0, pitchCounter=0;

    public AudioEngine(Context ctx){
        manager=(AudioManager)ctx.getSystemService(Context.AUDIO_SERVICE);
        nativeBurstFrames=readNativeBurst();
    }

    private int readNativeBurst(){
        try{
            String v=manager.getProperty(AudioManager.PROPERTY_OUTPUT_FRAMES_PER_BUFFER);
            int n=Integer.parseInt(v);
            return n>=64 && n<=2048 ? n : DEFAULT_BURST;
        }catch(Exception ignored){ return DEFAULT_BURST; }
    }

    public JSONArray deviceJson(boolean inputs){ JSONArray a=new JSONArray(); for(AudioDeviceInfo d: manager.getDevices(inputs?AudioManager.GET_DEVICES_INPUTS:AudioManager.GET_DEVICES_OUTPUTS)){ try{JSONObject o=new JSONObject();o.put("id",d.getId());o.put("name",d.getProductName().toString());o.put("type",d.getType());o.put("usb",isUsb(d));a.put(o);}catch(Exception ignored){}} return a; }
    private boolean isUsb(AudioDeviceInfo d){int t=d.getType();return t==AudioDeviceInfo.TYPE_USB_DEVICE||t==AudioDeviceInfo.TYPE_USB_HEADSET||t==AudioDeviceInfo.TYPE_USB_ACCESSORY;}
    private AudioDeviceInfo find(int id, boolean source){ AudioDeviceInfo[] ds=manager.getDevices(source?AudioManager.GET_DEVICES_INPUTS:AudioManager.GET_DEVICES_OUTPUTS); AudioDeviceInfo usb=null; for(AudioDeviceInfo d:ds){if(d.getId()==id)return d;if(usb==null&&isUsb(d))usb=d;} return usb; }

    public synchronized String start(int inputId,int outputId){ return start(inputId,outputId,"low"); }

    public synchronized String start(int inputId,int outputId,String requestedMode){
        stop(); lastError=""; routeWarning="";
        latencyMode="stable".equalsIgnoreCase(requestedMode)?"stable":"low";
        nativeBurstFrames=readNativeBurst();
        // In LOW mode process about half a native burst at a time, with a 64-frame floor.
        blockFrames="low".equals(latencyMode)?Math.max(64,Math.min(128,Math.max(64,nativeBurstFrames/2))):Math.max(192,nativeBurstFrames);
        try{
            AudioDeviceInfo in=find(inputId,true), out=find(outputId,false);
            if(in==null) return fail("No USB input is exposed to Android AudioRecord.");
            if(!isUsb(in)) return fail("Selected input is not a USB audio interface. Refusing the phone/ambient microphone.");

            int minIn=AudioRecord.getMinBufferSize(SR,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_FLOAT);
            int minOut=AudioTrack.getMinBufferSize(SR,AudioFormat.CHANNEL_OUT_STEREO,AudioFormat.ENCODING_PCM_FLOAT);
            if(minIn<0 || minOut<0) return fail("Android reported an unsupported 48 kHz PCM-float audio configuration.");

            int periods="low".equals(latencyMode)?2:4;
            int desiredInFrames=Math.max(blockFrames*periods,nativeBurstFrames*periods);
            int desiredOutFrames=Math.max(blockFrames*periods,nativeBurstFrames*periods);
            int inBytes=Math.max(minIn,desiredInFrames*4);       // mono float = 4 bytes/frame
            int outBytes=Math.max(minOut,desiredOutFrames*8);    // stereo float = 8 bytes/frame

            // VOICE_PERFORMANCE is specifically intended for real-time captured/processed/playback audio.
            record=null;
            if(Build.VERSION.SDK_INT>=29){
                record=buildRecorder(MediaRecorder.AudioSource.VOICE_PERFORMANCE,inBytes,true);
                if(record!=null && record.getState()==AudioRecord.STATE_INITIALIZED) captureSource="VOICE_PERFORMANCE";
            }
            if(record==null || record.getState()!=AudioRecord.STATE_INITIALIZED){
                try { if(record!=null) record.release(); } catch(Exception ignored){}
                record=buildRecorder(MediaRecorder.AudioSource.UNPROCESSED,inBytes,true);
                if(record!=null && record.getState()==AudioRecord.STATE_INITIALIZED){
                    captureSource="UNPROCESSED";
                    routeWarning+="VOICE_PERFORMANCE was unavailable; using UNPROCESSED low-latency capture. ";
                }
            }
            if(record==null || record.getState()!=AudioRecord.STATE_INITIALIZED){
                try { if(record!=null) record.release(); } catch(Exception ignored){}
                record=buildRecorder(MediaRecorder.AudioSource.DEFAULT,inBytes,false);
                captureSource="DEFAULT";
                routeWarning+="Low-latency capture sources were unavailable; Android DEFAULT source is being used with explicit USB routing. ";
            }
            if(record==null || record.getState()!=AudioRecord.STATE_INITIALIZED) return fail("Android could not initialize a native audio recorder for the USB interface.");
            if(!record.setPreferredDevice(in)) return fail("Android refused the selected USB input device before recording started.");

            track=new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).setFlags(AudioAttributes.FLAG_LOW_LATENCY).build())
                    .setAudioFormat(new AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_FLOAT).setSampleRate(SR).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build())
                    .setBufferSizeInBytes(outBytes)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
                    .build();
            if(track.getState()!=AudioTrack.STATE_INITIALIZED) return fail("Android could not initialize the low-latency audio output.");

            // Ask AudioTrack to use the smallest practical buffer for this mode.
            int targetTrackFrames=Math.max(nativeBurstFrames*("low".equals(latencyMode)?2:4),blockFrames*2);
            try { track.setBufferSizeInFrames(targetTrackFrames); } catch(Exception ignored){}
            if(out!=null && !track.setPreferredDevice(out)) routeWarning += "Android did not accept the preferred output device; system routing will be used. ";

            activeInputId=in.getId();
            activeOutputId=out==null?-1:out.getId();
            activeInput=in.getProductName()+" (#"+in.getId()+")";
            activeOutput=out==null?"Android default output":out.getProductName()+" (#"+out.getId()+")";

            inputBufferFrames=record.getBufferSizeInFrames();
            outputBufferFrames=track.getBufferSizeInFrames();
            estimatedBufferLatencyMs=((inputBufferFrames+outputBufferFrames)*1000f)/SR;

            record.startRecording();
            try { Thread.sleep(30); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
            AudioDeviceInfo routedIn = record.getRoutedDevice();
            if (routedIn != null) {
                activeInput=routedIn.getProductName()+" (#"+routedIn.getId()+")";
                activeInputId=routedIn.getId();
                if (routedIn.getId() != in.getId() || !isUsb(routedIn)) {
                    String actual = activeInput;
                    try { record.stop(); } catch (Exception ignored) {}
                    try { record.release(); } catch (Exception ignored) {}
                    record = null;
                    try { track.release(); } catch (Exception ignored) {}
                    track = null;
                    return fail("Android routed input to "+actual+" instead of the selected USB interface. Live audio was stopped to prevent ambient-mic capture.");
                }
                routeConfirmed=true;
            } else {
                routeConfirmed=false;
                routeWarning += "Android did not report a routed input device; preferred USB routing is active but could not be independently confirmed. ";
            }

            track.play();
            try { Thread.sleep(20); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
            AudioDeviceInfo routedOut = track.getRoutedDevice();
            if(routedOut!=null){ activeOutput=routedOut.getProductName()+" (#"+routedOut.getId()+")"; activeOutputId=routedOut.getId(); }

            running.set(true);
            thread=new Thread(this::loop,"StadiumAudio");
            thread.start();
            return "Native USB audio started • "+latencyMode.toUpperCase()+" • "+captureSource+" • "+blockFrames+"f DSP • ~"+Math.round(estimatedBufferLatencyMs)+" ms buffers • "+activeInput+" → "+activeOutput+(routeWarning.isEmpty()?"":" • "+routeWarning.trim());
        }catch(Exception e){ stop(); return fail(e.getClass().getSimpleName()+": "+e.getMessage()); }
    }

    private AudioRecord buildRecorder(int source, int bufferBytes, boolean requestLowLatency){
        try{
            AudioRecord.Builder b=new AudioRecord.Builder()
                    .setAudioSource(source)
                    .setAudioFormat(new AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_FLOAT).setSampleRate(SR).setChannelMask(AudioFormat.CHANNEL_IN_MONO).build())
                    .setBufferSizeInBytes(bufferBytes);
            // AudioRecord does not expose an AudioTrack-style performance-mode flag.
            // Low-latency capture is requested through VOICE_PERFORMANCE / UNPROCESSED
            // plus the smallest practical buffer and explicit USB device routing.
            return b.build();
        }catch(Exception ignored){ return null; }
    }
    private String fail(String s){lastError=s;return "ERROR: "+s;}
    public synchronized void stop(){running.set(false);if(thread!=null){try{thread.join(250);}catch(Exception ignored){}thread=null;}try{if(record!=null){record.stop();record.release();}}catch(Exception ignored){}try{if(track!=null){track.stop();track.release();}}catch(Exception ignored){}record=null;track=null;routeConfirmed=false;activeInputId=-1;activeOutputId=-1;inputBufferFrames=0;outputBufferFrames=0;estimatedBufferLatencyMs=0;outputUnderruns=0;}

    private void loop(){ Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO); float[] in=new float[blockFrames], out=new float[blockFrames*2]; while(running.get()){int n=record.read(in,0,in.length,AudioRecord.READ_BLOCKING);if(n<=0)continue;double si=0,so=0;for(int i=0;i<n;i++){float raw=clamp(in[i]*inputGain);si+=raw*raw;pitchBuf[pitchPos++]=raw;if(pitchPos>=pitchBuf.length)pitchPos=0;float y=process(raw);if(mute)y=0;y=clamp(y*master);so+=y*y;out[i*2]=y;out[i*2+1]=y;}inputMeter=(float)Math.sqrt(si/n);outputMeter=(float)Math.sqrt(so/n);track.write(out,0,n*2,AudioTrack.WRITE_BLOCKING);try{outputUnderruns=track.getUnderrunCount();}catch(Exception ignored){}pitchCounter+=n;if(pitchCounter>SR/8){pitchCounter=0;estimatePitch();}} }
    private float process(float x){ if(dry)return x; float y=x;
        if(comp)y=compress(y);
        if(od1)y=blend(y,drive(y,od1Gain,od1Tone),od1Mix);
        if(od2)y=blend(y,drive(y,od2Gain,od2Tone),od2Mix);
        if(amp)y=amp(y);
        if(cab)y=cab(y);
        if(chorus)y=blend(y,chorus(y),chorusMix);
        if(delay)y=delay(y);
        if(reverb)y=reverb(y);
        if(swellGain!=swellTarget){swellGain += (swellTarget-swellGain)*.0025f;if(Math.abs(swellTarget-swellGain)<.001f)swellGain=swellTarget;}
        return y*swellGain;
    }
    private float compress(float x){float a=Math.abs(x);float atk=.002f+.04f*compAttack, rel=.03f+.35f*compRelease;float ca=(float)Math.exp(-1f/(SR*atk)),cr=(float)Math.exp(-1f/(SR*rel));compEnv=a>compEnv?ca*compEnv+(1-ca)*a:cr*compEnv+(1-cr)*a;float th=.03f+.32f*(1-compThreshold);float ratio=1.5f+7*compRatio;float g=1;if(compEnv>th)g=(float)Math.pow(th/compEnv,1-1/ratio);return blend(x,x*g*1.35f,compMix);}
    private float drive(float x,float gain,float tone){float g=1+gain*18;float d=(float)Math.tanh(x*g);lp += (.03f+tone*.15f)*(d-lp);return d*(.72f+tone*.18f)+lp*(.28f-tone*.18f);}
    private float amp(float x){float g=(1+ampDrive*9)*(ampBoost?1.7f:1);float z=(float)Math.tanh(x*g);float lowAlpha=.02f;lp+=lowAlpha*(z-lp);float high=z-lp;float mid=z-(high*.45f+lp*.55f);float v=lp*(.55f+ampBass)+mid*(.55f+ampMid)+high*(.35f+ampTreble*.75f);return (float)Math.tanh(v*1.15f);}
    private float cab(float x){float hpA=.992f-cabLow*.01f;float hp=hpA*(hpPrevOut+x-hpPrevIn);hpPrevIn=x;hpPrevOut=hp;float fc=3800+cabHigh*7000;float a=(float)(1-Math.exp(-2*Math.PI*fc/SR));cabLp+=a*(hp-cabLp);float reson=(cabLp-lp)*(cabRes-.5f)*.35f;return cabLp+reson;}
    private float chorus(float x){chorusBuf[chorusPos]=x;chorusPhase+=2*Math.PI*(.15+chorusRate*2.2)/SR;if(chorusPhase>2*Math.PI)chorusPhase-=2*Math.PI;int d=(int)(480+chorusDepth*500*(.5+.5*Math.sin(chorusPhase)));int r=chorusPos-d;if(r<0)r+=chorusBuf.length;float y=chorusBuf[r];chorusPos=(chorusPos+1)%chorusBuf.length;return y;}
    private float delay(float x){int delaySamples=Math.max(1,Math.min(delayBuf.length-1,(int)(SR*(45.0/bpm))));int r=delayPos-delaySamples;if(r<0)r+=delayBuf.length;float wet=delayBuf[r];float fb=delayHold?.965f:(.08f+delayFeedback*.74f);delayBuf[delayPos]=clamp(x+wet*fb);delayPos=(delayPos+1)%delayBuf.length;return x+wet*delayMix;}
    private float reverb(float x){float sum=0;float fb=.58f+revDecay*.32f;for(int i=0;i<revBuf.length;i++){float[] b=revBuf[i];int p=revPos[i];float y=b[p];b[p]=clamp(x*.22f+y*fb);revPos[i]=(p+1)%b.length;sum+=y;}return x+sum*.25f*revMix;}
    private float blend(float dry,float wet,float mix){return dry*(1-mix)+wet*mix;}
    private float clamp(float x){return Math.max(-1f,Math.min(1f,x));}

    public void triggerSwell(){swellGain=.001f;swellTarget=1f;}
    public void setDelayHold(boolean on){delayHold=on;}
    public void tapTempo(long ms){ if(tapN>0&&ms-taps[(tapN-1)%4]>2500)tapN=0;taps[tapN%4]=ms;tapN++;if(tapN>=2){int count=Math.min(tapN,4),start=Math.max(0,tapN-count);double total=0;int n=0;for(int i=start+1;i<tapN;i++){long a=taps[(i-1)%4],b=taps[i%4];if(b>a){total+=b-a;n++;}}if(n>0)bpm=(float)Math.max(40,Math.min(240,60000/(total/n)));}}

    public void applyState(String json){try{JSONObject s=new JSONObject(json);inputGain=(float)s.optDouble("inputGain",inputGain);master=(float)s.optDouble("master",master);bpm=(float)s.optDouble("bpm",bpm);ampBoost=s.optBoolean("ampBoost",ampBoost);delayHold=s.optBoolean("delayHold",delayHold);mute=s.optBoolean("muted",mute);dry=s.optBoolean("dry",dry);JSONArray bs=s.optJSONArray("blocks");if(bs!=null)for(int i=0;i<bs.length();i++){JSONObject b=bs.getJSONObject(i);String id=b.optString("id");boolean on=b.optBoolean("on",true);JSONObject p=b.optJSONObject("p");if("comp".equals(id)){comp=on;compThreshold=f(p,"Threshold",compThreshold);compRatio=f(p,"Ratio",compRatio);compAttack=f(p,"Attack",compAttack);compRelease=f(p,"Release",compRelease);compMix=f(p,"Mix",compMix);}else if("od1".equals(id)){od1=on;od1Gain=f(p,"Gain",od1Gain);od1Tone=f(p,"Tone",od1Tone);od1Mix=f(p,"Mix",od1Mix);}else if("od2".equals(id)){od2=on;od2Gain=f(p,"Gain",od2Gain);od2Tone=f(p,"Tone",od2Tone);od2Mix=f(p,"Mix",od2Mix);}else if("amp".equals(id)){amp=on;ampDrive=f(p,"Drive",ampDrive);ampBass=f(p,"Bass",ampBass);ampMid=f(p,"Mid",ampMid);ampTreble=f(p,"Treble",ampTreble);ampCut=f(p,"Cut",ampCut);}else if("cab".equals(id)){cab=on;cabLow=f(p,"Low Cut",cabLow);cabHigh=f(p,"High Cut",cabHigh);cabRes=f(p,"Resonance",cabRes);}else if("mod".equals(id)){chorus=on;chorusRate=f(p,"Rate",chorusRate);chorusDepth=f(p,"Depth",chorusDepth);chorusMix=f(p,"Mix",chorusMix);}else if("delay".equals(id)){delay=on;delayFeedback=f(p,"Feedback",delayFeedback);delayMix=f(p,"Mix",delayMix);delayTone=f(p,"Tone",delayTone);}else if("reverb".equals(id)){reverb=on;revMix=f(p,"Mix",revMix);revDecay=f(p,"Decay",revDecay);}}}catch(Exception e){lastError="State sync: "+e.getMessage();}}
    private float f(JSONObject p,String k,float d){return p==null?d:(float)p.optDouble(k,d);}

    private void estimatePitch(){float[] b=new float[pitchBuf.length];int p=pitchPos;for(int i=0;i<b.length;i++)b[i]=pitchBuf[(p+i)%b.length];double rms=0;for(float v:b)rms+=v*v;rms=Math.sqrt(rms/b.length);if(rms<.008){pitchHz=0;note="—";cents=0;return;}int minLag=SR/1000,maxLag=SR/55,best=0;double bestVal=0;for(int lag=minLag;lag<=maxLag;lag+=2){double sum=0;for(int i=0;i<b.length-lag;i+=2)sum+=b[i]*b[i+lag];if(sum>bestVal){bestVal=sum;best=lag;}}if(best==0)return;float f=SR/(float)best;double nn=12*Math.log(f/440.0)/Math.log(2)+69;int n=(int)Math.round(nn);String[] names={"C","C♯","D","D♯","E","F","F♯","G","G♯","A","A♯","B"};note=names[(n%12+12)%12]+(n/12-1);pitchHz=f;cents=(float)((nn-n)*100);}

    public String statusJson(){try{JSONObject o=new JSONObject();o.put("running",running.get());o.put("input",activeInput);o.put("output",activeOutput);o.put("routeConfirmed",routeConfirmed);o.put("inputId",activeInputId);o.put("outputId",activeOutputId);o.put("inputMeter",inputMeter);o.put("outputMeter",outputMeter);o.put("pitch",pitchHz);o.put("note",note);o.put("cents",cents);o.put("bpm",bpm);o.put("delayMs",Math.round(45000/bpm));o.put("error",lastError);o.put("warning",routeWarning);o.put("latencyMode",latencyMode);o.put("captureSource",captureSource);o.put("nativeBurstFrames",nativeBurstFrames);o.put("blockFrames",blockFrames);o.put("inputBufferFrames",inputBufferFrames);o.put("outputBufferFrames",outputBufferFrames);o.put("estimatedBufferLatencyMs",estimatedBufferLatencyMs);o.put("outputUnderruns",outputUnderruns);return o.toString();}catch(Exception e){return "{}";}}
}
